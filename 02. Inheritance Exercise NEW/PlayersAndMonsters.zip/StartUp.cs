﻿using System;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //MuseElf ms = new MuseElf("Krasi", 10);
            //Console.WriteLine(ms);
            //Elf e = new Elf("paco", 20);
            //Console.WriteLine(e);
            //SoulMaster sm = new SoulMaster("Dail", 15);
            //Console.WriteLine(sm);
        }
    }
}
