//using CarManager;
using NUnit.Framework;
using System;

namespace Tests
{
    public class CarTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestConstructorForCorrectInitialization()
        {
            string make = "BMW";
            string model = "MK3";
            double fuelConsumption = 10; ;
            double fuelCapacity = 70; ;

            Car car = new Car("BMW", "MK3", 10, 70);

            Assert.AreEqual(make, car.Make);
            Assert.AreEqual(model, car.Model);
            Assert.AreEqual(fuelConsumption, car.FuelConsumption);
            Assert.AreEqual(fuelCapacity, car.FuelCapacity);
        }
        [Test]
        public void TestMakeForNullEmpty()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("", "MK3", 10, 70);
            });
        }
        [Test]
        public void TestModelForNullEmpty()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("BMW", "", 10, 70);
            });
        }
        [Test]
        public void TestZeroFuelConsumption()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("BMW", "MK3", 0, 70);
            });
        }
        [Test]
        public void TestNegativeFuelConsumption()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("BMW", "MK3", -10, 70);
            });
        }
        [Test]
        public void TestNegativeFuelCapacity()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("BMW", "MK3", 10, -10);
            });
        }
        [Test]
        public void TestZeroFuelCapacity()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car car = new Car("BMW", "MK3", 10, 0);
            });
        }
        [Test]
        public void TestRefuelWithZero()
        {
            Car car = new Car("BMW", "MK3", 10, 70);
            Assert.Throws<ArgumentException>(() =>
            {
                car.Refuel(0);
            });
        }
        [Test]
        public void TestRefuelWithNegativeNumber()
        {
            Car car = new Car("BMW", "MK3", 10, 70);
            Assert.Throws<ArgumentException>(() =>
            {
                car.Refuel(-10);
            });
        }
        [Test]
        public void TestRefuelFuelAmount()
        {
            Car car = new Car("BMW", "MK3", 10, 70);

            double expectedFuelAmount = 30;
            car.Refuel(30);

            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }
        [Test]
        public void TestIfRefuelMoreThanCapacity()
        {
            Car car = new Car("BMW", "MK3", 10, 70);
            car.Refuel(100);
            int expectedFuel = 70;

            Assert.AreEqual(expectedFuel, car.FuelAmount);
        }
        [Test]
        public void TestNegativeFuelAmount()
        {
            Car car = new Car("BMW", "MK3", 10, 70);

            Assert.AreEqual(0, car.FuelAmount);

        }
        [Test]
        public void TestDriveMoreKilometers()
        {
            Car car = new Car("BMW", "MK3", 10, 70);

            Assert.Throws<InvalidOperationException>(() =>
            {
                car.Drive(1000);
            });
        }
        [Test]
        public void TestDriveLessKilometers()
        {
            Car car = new Car("BMW", "MK3", 10, 70);
            car.Refuel(10);
            var expectedFuelAmount = 9;
            car.Drive(10);
            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }




        //private Car car;

        //[SetUp]
        //public void Setup()
        //{
        //    car = new Car("Audi", "A4", 15, 300);
        //}

        //[Test]
        //public void TestIfConstructorWorksCorrectly()
        //{
        //    Assert.IsNotNull(this.car);
        //}

        //[Test]
        //public void TestMakeValidation()
        //{
        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        Car newCar = new Car(null, "A4", 15, 300);
        //    });
        //}

        //[Test]
        //public void TestModelValidation()
        //{
        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        Car newCar = new Car("Audi", null, 15, 300);
        //    });
        //}

        //[Test]
        //public void TestFuelConsumptionValidation()
        //{
        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        Car newCar = new Car("Audi", "A4", -3, 300);
        //    });
        //}

        //[Test]
        //public void TestFuelCapacityValidation()
        //{
        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        Car newCar = new Car("Audi", "A4", 15, 0);
        //    });
        //}

        //[Test]
        //public void TestFuelAmount()
        //{
        //    Assert.AreEqual(0, this.car.FuelAmount);
        //}

        //[Test]
        //public void TestRefuelingCorrectly()
        //{
        //    this.car.Refuel(15);
        //    int expectedFuel = 15;

        //    Assert.AreEqual(expectedFuel, this.car.FuelAmount);
        //}

        //[Test]
        //public void TestIfFuelToRefuelIsNegativeNumber()
        //{
        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        this.car.Refuel(-3);
        //    });
        //}
        //[Test]
        //public void TestRefuelWithZero()
        //{

        //    Assert.Throws<ArgumentException>(() =>
        //    {
        //        this.car.Refuel(0);
        //    });
        //}
        //[Test]
        //public void TestIfRefuelMoreThanCapacity()
        //{
        //    this.car.Refuel(350);
        //    int expectedFuel = 300;

        //    Assert.AreEqual(expectedFuel, this.car.FuelAmount);
        //}

        //[Test]
        //public void TestDrivingCorrectly()
        //{
        //    this.car.Refuel(10);
        //    this.car.Drive(10);
        //    double expectedFuel = 8.5;

        //    Assert.AreEqual(expectedFuel, this.car.FuelAmount);
        //}

        //[Test]
        //public void TestDrivingTooMuchDistance()
        //{
        //    this.car.Refuel(1);

        //    Assert.Throws<InvalidOperationException>(() =>
        //    {
        //        this.car.Drive(10);
        //    });
        //}

    }
}