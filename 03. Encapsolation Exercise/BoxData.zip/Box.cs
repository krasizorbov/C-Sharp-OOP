﻿using System;


namespace BoxData
{
    public class Box
    {
        double length;
        double width;
        double height;
        public Box(double length, double width, double height)
        {
            Length = length;
            Width = width;
            Height = height;
        }
        public double Length
        {
            get
            {
                return length;
            }
            set
            {
                if (value < 1)
                {
                    Console.WriteLine("Length cannot be zero or negative.");
                    Environment.Exit(0);
                }
                length = value;
            }
        }
        public double Width
        {
            get
            {
                return width;
            }
            set
            {
                if (value < 1)
                {
                    Console.WriteLine("Width cannot be zero or negative.");
                    Environment.Exit(0);
                }
                width = value;
            }
        }
        public double Height
        {
            get
            {
                return height;
            }
            set
            {
                if (value < 1)
                {
                    Console.WriteLine("Height cannot be zero or negative.");
                    Environment.Exit(0);
                }
                height = value;
            }
        }
        public string Surface()
        {
            //2lw + 2lh + 2wh
            double surfaceArea = 2 * width * length + 2 * length * height + 2 * width * height;
            return $"Surface Area - {surfaceArea:F2}";
        }
        public string Lateral()
        {
            //2lh + 2wh
            double lateralSurfaceArea = 2 * length * height + 2 * width * height;
            return $"Lateral Surface Area - {lateralSurfaceArea:F2}";
        }
        public string Volume()
        {
            //lwh
            double volume = length * width * height;
            return $"Volume - {volume:F2}";
        }
    }
}
