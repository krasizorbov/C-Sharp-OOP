﻿namespace ShoppingSpree
{
    public interface IReadOnlyCollection
    {
    }
}