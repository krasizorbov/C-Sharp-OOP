﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        const double increase = 1.6;
        public Truck(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
        {
        }

        public override void Driving(double distance)
        {
            double fuelNeeded = distance * (FuelConsumption + increase);
            if (FuelQuantity >= fuelNeeded)
            {
                FuelQuantity -= fuelNeeded;
                Console.WriteLine($"Truck travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Truck needs refueling");
            }
        }

        public override void Refueling(double amount)
        {
            FuelQuantity += amount * 0.95;
        }
    }
}
