﻿using System;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;


namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] carInput = Console.ReadLine().Split().ToArray();
            double carFuelQuantity = double.Parse(carInput[1]);
            double carFuelConsumption = double.Parse(carInput[2]);

            string[] truckInput = Console.ReadLine().Split().ToArray();
            double truckFuelQuantity = double.Parse(truckInput[1]);
            double truckFuelConsumption = double.Parse(truckInput[2]);

            Vehicle car = new Car(carFuelQuantity, carFuelConsumption);
            Vehicle truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            int a = int.Parse(Console.ReadLine());

            for (int i = 0; i < a; i++)
            {
                string[] input = Console.ReadLine().Split().ToArray();
                if (input[0] == "Drive")
                {
                    if (input[1] == "Car")
                    {
                        double kilometersToDrive = double.Parse(input[2]);
                        car.Driving(kilometersToDrive);
                    }
                    else if(input[1] == "Truck")
                    {
                        double kilometersToDrive = double.Parse(input[2]);
                        truck.Driving(kilometersToDrive);
                    }
                }
                else if (input[0] == "Refuel")
                {
                    if (input[1] == "Car")
                    {
                        double amount = double.Parse(input[2]);
                        car.Refueling(amount);
                    }
                    else if (input[1] == "Truck")
                    {
                        double amount = double.Parse(input[2]);
                        truck.Refueling(amount);
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
