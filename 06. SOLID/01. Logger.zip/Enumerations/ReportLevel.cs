﻿using System;
using System.Collections.Generic;
using System.Text;

public enum ReportLevel
{
    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL
}