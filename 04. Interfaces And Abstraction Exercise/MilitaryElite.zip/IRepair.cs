﻿namespace MilitaryElite
{
    public interface IRepair
    {
        string Part { get; }

        int Hours { get; }
    }
}