﻿namespace MilitaryElite
{
    public interface ISpy : ISoldier
    {
        int Code { get; }
    }
}