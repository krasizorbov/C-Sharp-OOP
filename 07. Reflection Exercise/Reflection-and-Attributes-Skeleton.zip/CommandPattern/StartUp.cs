﻿using System;

namespace CommandPattern
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //ICommandInterpreter command = new CommandInterpreter();
            //IEngine engine = new Engine(command);
            //engine.Run();
        }
    }
}
