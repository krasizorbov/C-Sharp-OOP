﻿using System;

[Author("Dancho")]
class Program
{
    [Author("Yovcho")]
    static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
    }
}